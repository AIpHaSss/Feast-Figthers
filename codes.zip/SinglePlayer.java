package backup;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.Field;

public class SinglePlayer extends JPanel {

    private final MiniAdventureStickman gamePanel;

    private boolean highScoreChecked = false;

    public SinglePlayer() {
        setLayout(new BorderLayout());

        gamePanel = new MiniAdventureStickman();
        add(gamePanel, BorderLayout.CENTER);

        setFocusable(true);
        gamePanel.setFocusable(true);

        enforceSinglePlayerRules();

        new Timer(150, e -> enforceSinglePlayerRules()).start();

        new Timer(100, e -> checkHighScore()).start();

        SwingUtilities.invokeLater(() -> {
            requestFocusInWindow();
            gamePanel.requestFocusInWindow();
        });
    }
    
    private void enforceSinglePlayerRules() {
        try {
            setBoolean("singlePlayerMode", true);

            setInt("player2Size", 0);
            setInt("player2X", -5000);
            setInt("player2Y", -5000);

        } catch (Exception ignored) {}
    }

    private void checkHighScore() {
        if (highScoreChecked) return;

        try {
            boolean gameOver = (boolean) getField("gameOver");
            if (!gameOver) return;

            highScoreChecked = true;

            int score1 = (int) getField("score1");

            if (score1 > GameLauncher.SINGLE_PLAYER_HIGH_SCORE) {
                GameLauncher.SINGLE_PLAYER_HIGH_SCORE = score1;
            }

        } catch (Exception ignored) {}
    }

    private Object getField(String name) throws Exception {
        Field f = MiniAdventureStickman.class.getDeclaredField(name);
        f.setAccessible(true);
        return f.get(gamePanel);
    }

    private void setInt(String name, int value) throws Exception {
        Field f = MiniAdventureStickman.class.getDeclaredField(name);
        f.setAccessible(true);
        f.setInt(gamePanel, value);
    }

    private void setBoolean(String name, boolean value) throws Exception {
        Field f = MiniAdventureStickman.class.getDeclaredField(name);
        f.setAccessible(true);
        f.setBoolean(gamePanel, value);
    }
}
