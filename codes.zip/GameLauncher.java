package backup;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class GameLauncher {

    public static int SINGLE_PLAYER_HIGH_SCORE = 0;

    private static final String MENU_BG = "1.png";

    private JFrame frame;
    private MenuPanel menuPanel;

    public GameLauncher() {

        frame = new JFrame("Mini Adventure Launcher");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1280, 720);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        frame.setUndecorated(true);
        GraphicsDevice gd = GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice();
        gd.setFullScreenWindow(frame);

        menuPanel = new MenuPanel();
        frame.setContentPane(menuPanel);
        frame.setVisible(true);
    }

    private void startGame() {
        MiniAdventureStickman gamePanel = new MiniAdventureStickman();
        frame.setContentPane(gamePanel);
        frame.revalidate();
        frame.repaint();
        gamePanel.requestFocusInWindow();
    }

    private void startSinglePlayer() {
        SinglePlayer sp = new SinglePlayer();
        frame.setContentPane(sp);
        frame.revalidate();
        frame.repaint();
        sp.requestFocusInWindow();
    }

    private void startEndlessMode() {
        SinglePlayerEndless endless = new SinglePlayerEndless();
        frame.setContentPane(endless);
        frame.revalidate();
        frame.repaint();
        endless.requestFocusInWindow();
    }

    private class MenuPanel extends JPanel {

        private Image bg;

        private final String[] options = {
            "SINGLE PLAYER",
            "TWO PLAYER",
            "ENDLESS MODE",
            "OPTIONS",
            "EXIT"
        };

        private final Rectangle[] optionBounds = new Rectangle[options.length];
        private int baseX;
        private int baseY;
        private final int gap = 30;
        private final Font optionFont = new Font("Arial", Font.BOLD, 48);

        private int hoverIndex = -1;

        public MenuPanel() {
            setLayout(null);

            try {
                bg = ImageIO.read(new File(MENU_BG));
            } catch (IOException e) {
                bg = null;
            }

            for (int i = 0; i < optionBounds.length; i++) {
                optionBounds[i] = new Rectangle();
            }

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int idx = getOptionIndexAt(e.getPoint());

                    if (idx == 0) startSinglePlayer();
                    else if (idx == 1) startGame();
                    else if (idx == 2) startEndlessMode();
                    else if (idx == 4) System.exit(0);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hoverIndex = -1;
                    repaint();
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    int idx = getOptionIndexAt(e.getPoint());
                    if (idx != hoverIndex) {
                        hoverIndex = idx;
                        repaint();
                    }
                }
            });
        }

        private int getOptionIndexAt(Point p) {
            for (int i = 0; i < optionBounds.length; i++) {
                if (optionBounds[i].contains(p)) return i;
            }
            return -1;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;

            if (bg != null) {
                g2.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
            } else {
                g2.setColor(Color.BLACK);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }

            baseX = (int)(getWidth() * 0.12);
            g2.setFont(optionFont);
            FontMetrics fm = g2.getFontMetrics();

            int totalHeight =
                    options.length * fm.getHeight()
                  + (options.length - 1) * gap;

            baseY = (getHeight() - totalHeight) / 2;

            for (int i = 0; i < options.length; i++) {

                String text = options[i];
                int textWidth = fm.stringWidth(text);
                int textHeight = fm.getAscent();

                int x = baseX;
                int y = baseY + i * (fm.getHeight() + gap) + textHeight;

                int paddingX = 20;
                int paddingY = 8;

                optionBounds[i].setBounds(
                        x - paddingX,
                        y - textHeight - paddingY,
                        textWidth + paddingX * 2,
                        textHeight + paddingY * 2
                );

                boolean isHover = (i == hoverIndex);
                boolean isClickable =
                        (i == 0 || i == 1 || i == 2 || i == 4);

                g2.setColor(new Color(0, 0, 0, 120));
                g2.drawString(text, x + 3, y + 3);

                if (isClickable) {
                    g2.setColor(isHover
                            ? new Color(200, 255, 120)
                            : new Color(170, 230, 90));
                } else {
                    g2.setColor(isHover
                            ? new Color(180, 180, 180)
                            : new Color(130, 130, 130));
                }

                g2.drawString(text, x, y);
            }
        }
    }
}
